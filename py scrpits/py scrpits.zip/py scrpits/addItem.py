import os

itemName = input("Enter base item name:")

mainDir = str(os.getcwd())
langName = ""

maxcount = len(itemName.split("_"))
count = 0
for i in itemName.split("_"):
    langName += i.capitalize()
    count += 1
    if count != maxcount:
        langName += " "

#item model
os.chdir('../src/main/resources/assets/rankine/models/item/')

file = open(itemName+'.json','w+')
contents = """{{
  \"parent\": \"item/handheld\",
  \"textures\": {{
    \"layer0\": \"rankine:item/{}\"
  }}
}}""".format(itemName)
file.write(contents)
print("Generated "+file.name+"!")
file.close()

os.chdir(mainDir)




#registry
print("public static final Item {} = add(\"{}\", new Item(new Item.Properties().group(ProjectRankine.setup.rankineTools)));".format(itemName.upper(), itemName))

#lang
print("\"item.rankine.{}\": \"{}\",".format(itemName, langName))
