import os

mainDir = str(os.getcwd())

addList = ["blueberry","blackberry","raspberry","cranberry","strawberry"]
itemList = ["blueberries","blackberries","raspberries","cranberries","strawberries"]


for i in range(len(addList)):
    
    BLOCK = addList[i]
    ITEM = itemList[i]
    

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(BLOCK+'_bush.json','w+')
    contents = """{{
      \"variants\": {{
        \"age=0\": {{ \"model\": \"rankine:block/{item}_bush_stage0\" }},
        \"age=1\": {{ \"model\": \"rankine:block/{item}_bush_stage1\" }},
        \"age=2\": {{ \"model\": \"rankine:block/{item}_bush_stage2\" }},
        \"age=3\": {{ \"model\": \"rankine:block/{item}_bush_stage3\" }}
      }}
    }}""".format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(BLOCK+'_bush_stage0.json','w+')
    contents = """{{
      \"parent\": \"block/cross\",
      \"textures\": {{
        \"cross\": \"rankine:block/{item}_bush_stage0\"
      }}
    }}""".format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_bush_stage1.json','w+')
    contents = """{{
      \"parent\": \"block/cross\",
      \"textures\": {{
        \"cross\": \"rankine:block/{item}_bush_stage1\"
      }}
    }}""".format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_bush_stage2.json','w+')
    contents = """{{
      \"parent\": \"block/cross\",
      \"textures\": {{
        \"cross\": \"rankine:block/{item}_bush_stage2\"
      }}
    }}""".format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_bush_stage3.json','w+')
    contents = """{{
      \"parent\": \"block/cross\",
      \"textures\": {{
        \"cross\": \"rankine:block/{item}_bush_stage3\"
      }}
    }}""".format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(ITEM+'.json','w+')
    contents = """{{
      \"parent\": \"item/generated\",
      \"textures\": {{
        \"layer0\": \"rankine:item/{item}\"
      }}
    }}
    """.format(item=ITEM)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    
    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(BLOCK+'_bush.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1.0,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{ITEM}\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:block_state_property\",
              \"block\": \"rankine:{BLOCK}_bush\",
              \"properties\": {{
                \"age\": \"3\"
              }}
            }}
          ],
          \"functions\": [
            {{
              \"function\": \"minecraft:set_count\",
              \"count\": {{
                \"min\": 1.0,
                \"max\": 2.0,
                \"type\": \"minecraft:uniform\"
              }}
            }},
            {{
              \"function\": \"minecraft:apply_bonus\",
              \"enchantment\": \"minecraft:fortune\",
              \"formula\": \"minecraft:uniform_bonus_count\",
              \"parameters\": {{
                \"bonusMultiplier\": 1
              }}
            }}
          ]
        }},
        {{
          \"rolls\": 1.0,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{ITEM}\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:block_state_property\",
              \"block\": \"rankine:{BLOCK}_bush\",
              \"properties\": {{
                \"age\": \"2\"
              }}
            }}
          ],
          \"functions\": [
            {{
              \"function\": \"minecraft:set_count\",
              \"count\": {{
                \"min\": 1.0,
                \"max\": 1.0,
                \"type\": \"minecraft:uniform\"
              }}
            }},
            {{
              \"function\": \"minecraft:apply_bonus\",
              \"enchantment\": \"minecraft:fortune\",
              \"formula\": \"minecraft:uniform_bonus_count\",
              \"parameters\": {{
                \"bonusMultiplier\": 1
              }}
            }}
          ]
        }}
      ],
      "functions": [
        {{
          "function": "minecraft:explosion_decay"
        }}
      ]
    }}""".format(ITEM=ITEM, BLOCK=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)



i=0
for BLOCK in addList:
    print("public static final RankineBerryBushBlock {}_BUSH = add(\"{}_bush\", \"{}\", new RankineBerryBushBlock(Block.Properties.create(Material.PLANTS).tickRandomly().doesNotBlockMovement().sound(SoundType.SWEET_BERRY_BUSH),XXX), new Item.Properties().group(ProjectRankine.setup.rankineTools).food(ModFoods.{}), BlockNamedItem::new);".format(BLOCK.upper(), BLOCK, itemList[i], itemList[i].upper()))
    i+=1
for BLOCK in addList:
    langName = ""
    maxcount = len(BLOCK.split("_"))
    count = 0
    for i in BLOCK.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "
    print("\"block.rankine.{}_bush\": \"{}\",".format(BLOCK, langName + " Bush"))
for ITEM in addList:
    langName = ""
    maxcount = len(ITEM.split("_"))
    count = 0
    for i in ITEM.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "
    print("\"item.rankine.{}\": \"{}\",".format(ITEM, langName))
    
