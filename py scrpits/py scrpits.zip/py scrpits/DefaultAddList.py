import os
aaaaaaaaaaaaa
mainDir = str(os.getcwd())

addList = ["anthracite","lazurite","diamond","greenockite","emerald"]

for ITEM in addList:

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(ITEM+'_XXX.json','w+')
    contents = """{{
=======================
    }}""".format()
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(ITEM+'_XXX.json','w+')
    contents = """{{
==========================
    }}""".format()
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(ITEM+'_XXX.json','w+')
    contents = """{{
============================
    }}
    """.format()
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    
    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(ITEM+'_XXX.json','w+')
    contents = """{{
=============================
    }}""".format()
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


for ITEM in addList:
    print("public static final RankineOre {}_XXX = add(\"{}_xxx\", new RankineOre(DEF_ORE.harvestLevel(0)), METALLURGY);".format(ore.upper(), ore))
for ITEM in addList:
    langName = ""
    maxcount = len(ITEM.split("_"))
    count = 0
    for i in ITEM.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "
    print("\"block.rankine.{}_xxx\": \"{}\",".format(ITEM, langName + " XXXX"))
    
