import os

mainDir = str(os.getcwd())



stoneList = ["granite","diorite","andesite","limestone","shale","anorthosite","ironstone","basalt","rhyolite","marble","gneiss","peridotite","ringwoodite","wadsleyite","bridgmanite","komatiite","kimberlite","ferropericlase","perovskite","pumice","scoria"]
smooth = ["smooth_granite","smooth_diorite","smooth_andesite","smooth_limestone","smooth_shale","smooth_anorthosite","smooth_ironstone","smooth_basalt","smooth_rhyolite","smooth_marble","smooth_gneiss","smooth_peridotite","smooth_ringwoodite","smooth_wadsleyite","smooth_bridgmanite","smooth_komatiite","smooth_kimberlite","smooth_ferropericlase","smooth_perovskite","smooth_pumice","smooth_scoria"]
bricks = ["red_granite_bricks","quartz_diorite_bricks","gray_andesite_bricks","granite_bricks","diorite_bricks","andesite_bricks","limestone_bricks","shale_bricks","anorthosite_bricks","ironstone_bricks","basalt_bricks","rhyolite_bricks","marble_bricks","gneiss_bricks","peridotite_bricks","ringwoodite_bricks","wadsleyite_bricks","bridgmanite_bricks","komatiite_bricks","kimberlite_bricks","ferropericlase_bricks","perovskite_bricks","pumice_bricks","scoria_bricks"]
others = ["roman_concrete","smooth_roman_concrete","roman_concrete_bricks","bamboo","bamboo_clums"]

addList = stoneList + smooth + bricks + others

for i in range(len(addList)):
    
    BLOCK = addList[i]

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(BLOCK+'_wall.json','w+')
    contents = """{{
      \"multipart\": [
        {{
          \"when\": {{
            \"up\": \"true\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_post\"
          }}
        }},
        {{
          \"when\": {{
            \"north\": \"low\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side\",
            \"uvlock\": true
          }}
        }},
        {{
          \"when\": {{
            \"east\": \"low\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side\",
            \"y\": 90,
            \"uvlock\": true
          }}
        }},
        {{
          \"when\": {{
            \"south\": \"low\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side\",
            \"y\": 180,
            \"uvlock\": true
          }}
        }},
        {{
          \"when\": {{
            \"west\": \"low\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side\",
            \"y\": 270,
            \"uvlock\": true
          }}
        }},
        {{
          \"when\": {{
            \"north\": \"tall\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side_tall\",
            \"uvlock\": true
          }}
        }},
        {{
          \"when\": {{
            \"east\": \"tall\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side_tall\",
            \"y\": 90,
            \"uvlock\": true
          }}
        }},
        {{
          \"when\": {{
            \"south\": \"tall\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side_tall\",
            \"y\": 180,
            \"uvlock\": true
          }}
        }},
        {{
          \"when\": {{
            \"west\": \"tall\"
          }},
          \"apply\": {{
            \"model\": \"rankine:block/{item}_wall_side_tall\",
            \"y\": 270,
            \"uvlock\": true
          }}
        }}
      ]
    }}""".format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(BLOCK+'_wall_side.json','w+')
    contents = """{{
        "parent": "block/template_wall_side",
        "textures": {{
            "wall": "rankine:block/{item}"
        }}
    }}""".format(item=BLOCK)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_wall_side_tall.json','w+')
    contents = """{{
      \"parent\": \"minecraft:block/template_wall_side_tall\",
      \"textures\": {{
        \"wall\": \"rankine:block/{item}\"
      }}
    }}""".format(item=BLOCK)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_wall_post.json','w+')
    contents = """{{
        "parent": "block/template_wall_post",
        "textures": {{
            "wall": "rankine:block/{item}"
        }}
    }}""".format(item=BLOCK)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_wall_inventory.json','w+')
    contents = """{{
        "parent": "block/wall_inventory",
        "textures": {{
            "wall": "rankine:block/{item}"
        }}
    }}""".format(item=BLOCK)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(BLOCK+'_wall.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{item}_wall_inventory\"
    }}
    """.format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    
    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(BLOCK+'_bush.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\":
      [
        {{ \"rolls\": 1,
          \"entries\":
          [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{item}_wall\"
            }}
          ],
          \"conditions\":
          [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(item=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)



i=0
for BLOCK in addList:
    print("public static final Block {} = add(\"{}\", new WallBlock(DEF_STONE.harvestLevel(0)), BLOCKS);".format(BLOCK.upper(), BLOCK))
    i+=1
for BLOCK in addList:
    langName = ""
    maxcount = len(BLOCK.split("_"))
    count = 0
    for i in BLOCK.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "
    print("\"block.rankine.{}_wall\": \"{}\",".format(BLOCK, langName + " Wall"))
    
