#STONE PRESSURE PLATES
import os

mainDir = str(os.getcwd())



stoneList = ["granite","diorite","andesite","limestone","shale","anorthosite","ironstone","basalt","rhyolite","marble","gneiss","peridotite","ringwoodite","wadsleyite","bridgmanite","komatiite","kimberlite","ferropericlase","perovskite","pumice","scoria"]
smooth = ["smooth_granite","smooth_diorite","smooth_andesite","smooth_limestone","smooth_shale","smooth_anorthosite","smooth_ironstone","smooth_basalt","smooth_rhyolite","smooth_marble","smooth_gneiss","smooth_peridotite","smooth_ringwoodite","smooth_wadsleyite","smooth_bridgmanite","smooth_komatiite","smooth_kimberlite","smooth_ferropericlase","smooth_perovskite","smooth_pumice","smooth_scoria"]
bricks = ["red_granite_bricks","quartz_diorite_bricks","gray_andesite_bricks","granite_bricks","diorite_bricks","andesite_bricks","limestone_bricks","shale_bricks","anorthosite_bricks","ironstone_bricks","basalt_bricks","rhyolite_bricks","marble_bricks","gneiss_bricks","peridotite_bricks","ringwoodite_bricks","wadsleyite_bricks","bridgmanite_bricks","komatiite_bricks","kimberlite_bricks","ferropericlase_bricks","perovskite_bricks","pumice_bricks","scoria_bricks"]

addList = stoneList + smooth + bricks

for i in range(len(addList)):
    
    BLOCK = addList[i]

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(BLOCK+'_pressure_plate.json','w+')
    contents = """{{
      \"variants\": {{
        \"powered=false\": {{ \"model\": \"rankine:block/{BLK}_pressure_plate\" }},
        \"powered=true\": {{ \"model\": \"rankine:block/{BLK}_pressure_plate_down\" }}
      }}
    }}""".format(BLK=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(BLOCK+'_pressure_plate.json','w+')
    contents = """{{
      \"parent\": \"block/pressure_plate_up\",
      \"textures\": {{
        \"texture\": \"rankine:block/{}\"
      }}
    }}""".format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_pressure_plate_down.json','w+')
    contents = """{{
      \"parent\": \"block/pressure_plate_down\",
      \"textures\": {{
        \"texture\": \"rankine:block/{}\"
      }}
    }}""".format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(BLOCK+'_pressure_plate.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{}_pressure_plate\"
    }}
    """.format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    
    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(BLOCK+'_pressure_plate.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{}_pressure_plate\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(BLOCK+'_pressure_plate.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"pattern\": [
        \"##\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_pressure_plate\",
        \"count\": 1
      }}
    }}""".format(BLK=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(BLOCK+'_pressure_plate_from_'+BLOCK+'_stonecutter.json','w+')
    contents = """{{
      \"type\": \"minecraft:stonecutting\",
      \"ingredient\": {{
        \"item\": \"rankine:{BLK}\"
      }},
      \"result\": \"rankine:{BLK}_pressure_plate\",
      \"count\": 1
    }}""".format(BLK=BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)




for BLOCK in addList:
    print("public static final Block {}_PRESSURE_PLATE = add(\"{}_pressure_plate\", new RankineStonePressurePlate(), BLOCKS);".format(BLOCK.upper(), BLOCK))

for BLOCK in addList:
    langName = ""
    maxcount = len(BLOCK.split("_"))
    count = 0
    for i in BLOCK.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "
    print("\"block.rankine.{}_pressure_plate\": \"{}\",".format(BLOCK, langName + " Pressure Plate"))
    
