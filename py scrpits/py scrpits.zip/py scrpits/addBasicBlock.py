import os

mainDir = str(os.getcwd())

addList = ["nickel_sheetmetal","platinum_sheetmetal","titanium_sheetmetal"]


for i in range(len(addList)):
    
    BLOCK = addList[i]

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(BLOCK+'.json','w+')
    contents = """{{
        \"variants\": {{
        \"\": {{ \"model\": \"rankine:block/{}\" }}
        }}
    }}""".format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(BLOCK+'.json','w+')
    contents = """{{
        \"parent": \"block/cube_all\",
        \"textures\": {{
        \"all\": \"rankine:block/{}\"
        }}
    }}""".format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
   #item model
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(BLOCK+'.json','w+')
    contents = """{{
        \"parent\": \"rankine:block/{}\"
    }}""".format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(BLOCK+'.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\":
      [
        {{ \"rolls\": 1,
          \"entries\":
          [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{}\"
            }}
          ],
          \"conditions\":
          [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(BLOCK)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)



i=0
for BLOCK in addList:
    print("public static final Block {} = add(\"{}\", new Block(DEF_STONE.harvestLevel(0)), BLOCKS);".format(BLOCK.upper(), BLOCK))
    i+=1
for BLOCK in addList:
    langName = ""
    maxcount = len(BLOCK.split("_"))
    count = 0
    for i in BLOCK.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "
    print("\"block.rankine.{}\": \"{}\",".format(BLOCK, langName))
    
