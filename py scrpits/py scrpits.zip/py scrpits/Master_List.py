



stoneList = ["granite","diorite","andesite","limestone","shale","anorthosite","ironstone","basalt","rhyolite","marble","gneiss","peridotite","ringwoodite","wadsleyite","bridgmanite","komatiite","kimberlite","ferropericlase","perovskite","pumice","scoria"]
smooth = ["smooth_granite","smooth_diorite","smooth_andesite","smooth_limestone","smooth_shale","smooth_anorthosite","smooth_ironstone","smooth_basalt","smooth_rhyolite","smooth_marble","smooth_gneiss","smooth_peridotite","smooth_ringwoodite","smooth_wadsleyite","smooth_bridgmanite","smooth_komatiite","smooth_kimberlite","smooth_ferropericlase","smooth_perovskite","smooth_pumice","smooth_scoria"]
bricks = ["red_granite_bricks","quartz_diorite_bricks","gray_andesite_bricks","granite_bricks","diorite_bricks","andesite_bricks","limestone_bricks","shale_bricks","anorthosite_bricks","ironstone_bricks","basalt_bricks","rhyolite_bricks","marble_bricks","gneiss_bricks","peridotite_bricks","ringwoodite_bricks","wadsleyite_bricks","bridgmanite_bricks","komatiite_bricks","kimberlite_bricks","ferropericlase_bricks","perovskite_bricks","pumice_bricks","scoria_bricks"]
oreList = ["magnetite","cassiterite","malachite","bauxite","sphalerite","cinnabar","pentlandite","magnesite","galena","vanadinite","bismite","acanthite","pyrolusite","chromite","molybdenite","ilmenite","columbite","wolframite","tantalite","plumbago","moissanite","sperrylite","lignite","subbituminous","bituminous","anthracite","lazurite","diamond","greenockite","emerald","aquamarine","native_copper","native_tin","native_gold","native_aluminum","native_lead","native_silver","native_arsenic","native_bismuth","native_sulfur","native_gallium","native_indium","native_tellurium","native_selenium","nether_gold","quartz","opal","fluorite","uraninite"]



others = ["roman_concrete","smooth_roman_concrete","roman_concrete_bricks","bamboo","bamboo_clums"]
