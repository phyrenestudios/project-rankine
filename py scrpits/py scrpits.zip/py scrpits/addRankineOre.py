import os

#aaa

mainDir = str(os.getcwd())

stoneList = ["granite","diorite","andesite","limestone","shale","anorthosite","ironstone","basalt","rhyolite","marble","gneiss","peridotite","ringwoodite","wadsleyite","bridgmanite","komatiite","kimberlite","ferropericlase","perovskite","pumice","scoria"]
oreList = ["magnetite","cassiterite","malachite","bauxite","sphalerite","cinnabar","pentlandite","magnesite","galena","vanadinite","bismite","acanthite","pyrolusite","chromite","molybdenite","ilmenite","columbite","wolframite","tantalite","plumbago","moissanite","sperrylite","lignite","subbituminous","bituminous","anthracite","lazurite","diamond","greenockite","emerald","aquamarine","native_copper","native_tin","native_gold","native_aluminum","native_lead","native_silver","native_arsenic","native_bismuth","native_sulfur","native_gallium","native_indium","native_tellurium","native_selenium","nether_gold","quartz","opal","fluorite","uraninite"]

for ore in oreList:

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(ore+'_ore.json','w+')
    contents = """{{
      \"variants\": {{
        \"type=0\": {{\"model\": \"rankine:block/{ORE}_ore0\"}},
        \"type=1\": {{\"model\": \"rankine:block/{ORE}_ore1\"}},
        \"type=2\": {{\"model\": \"rankine:block/{ORE}_ore2\"}},
        \"type=3\": {{\"model\": \"rankine:block/{ORE}_ore3\"}},
        \"type=4\": {{\"model\": \"rankine:block/{ORE}_ore4\"}},
        \"type=5\": {{\"model\": \"rankine:block/{ORE}_ore5\"}},
        \"type=6\": {{\"model\": \"rankine:block/{ORE}_ore6\"}},
        \"type=7\": {{\"model\": \"rankine:block/{ORE}_ore7\"}},
        \"type=8\": {{\"model\": \"rankine:block/{ORE}_ore8\"}},
        \"type=9\": {{\"model\": \"rankine:block/{ORE}_ore9\"}},
        \"type=10\": {{\"model\": \"rankine:block/{ORE}_ore10\"}},
        \"type=11\": {{\"model\": \"rankine:block/{ORE}_ore11\"}},
        \"type=12\": {{\"model\": \"rankine:block/{ORE}_ore12\"}},
        \"type=13\": {{\"model\": \"rankine:block/{ORE}_ore13\"}},
        \"type=14\": {{\"model\": \"rankine:block/{ORE}_ore14\"}},
        \"type=15\": {{\"model\": \"rankine:block/{ORE}_ore15\"}},
        \"type=16\": {{\"model\": \"rankine:block/{ORE}_ore16\"}},
        \"type=17\": {{\"model\": \"rankine:block/{ORE}_ore17\"}},
        \"type=18\": {{\"model\": \"rankine:block/{ORE}_ore18\"}},
        \"type=19\": {{\"model\": \"rankine:block/{ORE}_ore19\"}},
        \"type=20\": {{\"model\": \"rankine:block/{ORE}_ore20\"}},
        \"type=21\": {{\"model\": \"rankine:block/{ORE}_ore21\"}},
        \"type=22\": {{\"model\": \"rankine:block/{ORE}_ore22\"}},
        \"type=23\": {{\"model\": \"rankine:block/{ORE}_ore23\"}},
        \"type=24\": {{\"model\": \"rankine:block/{ORE}_ore23\"}}
      }}
    }}""".format(ORE=ore)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(ore+'_ore0.json','w+')
    contents = """{{
      \"parent\": \"block/block\",
      \"textures\": {{
        \"base\": \"block/stone\",
        \"overlay\": \"rankine:block/{ORE}_ore\",
        \"particle\": \"block/stone\"
      }},
      \"elements\": [
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"east\" }}
          }}
        }},
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"east\" }}
          }}
        }}
      ]
    }}""".format(ORE=ore)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(ore+'_ore1.json','w+')
    contents = """{{
      \"parent\": \"block/block\",
      \"textures\": {{
        \"base\": \"block/netherrack\",
        \"overlay\": \"rankine:block/{ORE}_ore\",
        \"particle\": \"block/netherrack\"
      }},
      \"elements\": [
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"east\" }}
          }}
        }},
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"east\" }}
          }}
        }}
      ]
    }}""".format(ORE=ore)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(ore+'_ore2.json','w+')
    contents = """{{
      \"parent\": \"block/block\",
      \"textures\": {{
        \"base\": \"block/blackstone\",
        \"overlay\": \"rankine:block/{ORE}_ore\",
        \"particle\": \"block/blackstone\"
      }},
      \"elements\": [
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"east\" }}
          }}
        }},
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"east\" }}
          }}
        }}
      ]
    }}""".format(ORE=ore)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(ore+'_ore3.json','w+')
    contents = """{{
      \"parent\": \"block/block\",
      \"textures\": {{
        \"base\": \"block/end_stone\",
        \"overlay\": \"rankine:block/{ORE}_ore\",
        \"particle\": \"block/end_stone\"
      }},
      \"elements\": [
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"east\" }}
          }}
        }},
        {{   \"from\": [ 0, 0, 0 ],
          \"to\": [ 16, 16, 16 ],
          \"faces\": {{
            \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"down\" }},
            \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"up\" }},
            \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"north\" }},
            \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"south\" }},
            \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"west\" }},
            \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"east\" }}
          }}
        }}
      ]
    }}""".format(ORE=ore)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()




    i = 4
    for stone in stoneList:
        file = open(ore+"_ore{IND}.json".format(IND=i),'w+')
        contents = """{{
          \"parent\": \"block/block\",
          \"textures\": {{
            \"base\": \"rankine:block/{STONE}\",
            \"overlay\": \"rankine:block/{ORE}_ore\",
            \"particle\": \"rankine:block/{STONE}\"
          }},
          \"elements\": [
            {{   \"from\": [ 0, 0, 0 ],
              \"to\": [ 16, 16, 16 ],
              \"faces\": {{
                \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"down\" }},
                \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"up\" }},
                \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"north\" }},
                \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"south\" }},
                \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"west\" }},
                \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#base\",   \"cullface\": \"east\" }}
              }}
            }},
            {{   \"from\": [ 0, 0, 0 ],
              \"to\": [ 16, 16, 16 ],
              \"faces\": {{
                \"down\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"down\" }},
                \"up\":    {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"up\" }},
                \"north\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"north\" }},
                \"south\": {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"south\" }},
                \"west\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"west\" }},
                \"east\":  {{ \"uv\": [ 0, 0, 16, 16 ], \"texture\": \"#overlay\", \"tintindex\": 0, \"cullface\": \"east\" }}
              }}
            }}
          ]
        }}""".format(STONE=stone,ORE=ore)
        file.write(contents)
        print("Generated "+file.name+"!")
        file.close()
        i += 1

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(ore+'_ore.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{ORE}_ore0\"
    }}
    """.format(ORE=ore)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    
    os.chdir(mainDir)


##    #loottable
##    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')
##
##    file = open(ore+'_ore.json','w+')
##    contents = """{{
##      \"type\": \"minecraft:block\",
##      \"pools\": [
##        {{
##          \"rolls\": 1,
##          \"entries\": [
##            {{
##              \"type\": \"minecraft:item\",
##              \"name\": \"rankine:{ORE}_ore\"
##            }}
##          ],
##          \"conditions\": [
##            {{
##              \"condition\": \"minecraft:survives_explosion\"
##            }}
##          ]
##        }}
##      ]
##    }}""".format(ORE=ore)
##    file.write(contents)
##    print("Generated "+file.name+"!")
##    file.close()
##
##    os.chdir(mainDir)


for ore in oreList:
    print("public static final RankineOre {}_ORE = add(\"{}_ore\", new RankineOre(DEF_ORE.harvestLevel(0)), METALLURGY);".format(ore.upper(), ore))
for ore in oreList:
    langName = ""
    maxcount = len(ore.split("_"))
    count = 0
    for i in ore.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "
    print("\"block.rankine.{}_ore\": \"{}\",".format(ore, langName + " Ore"))
    
