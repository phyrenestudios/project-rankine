import os

#itemName = input("Enter base item name:")

mainDir = str(os.getcwd())

  
toAdd = ["hydrogen_ingot","helium_ingot","lithium_ingot","beryllium_ingot","boron_ingot","carbon_ingot","nitrogen_ingot","oxygen_ingot","fluorine_ingot","neon_ingot","sodium_ingot","magnesium_ingot","aluminum_ingot","silicon","phosphorus","sulfur","chlorine_ingot","argon_ingot",
         "potassium_ingot","calcium_ingot","scandium_ingot","titanium_ingot","vanadium_ingot","chromium_ingot","manganese_ingot","cobalt_ingot","nickel_ingot","copper_ingot","zinc_ingot","gallium_ingot","germanium_ingot","arsenic_ingot","selenium_ingot","bromine_ingot",
         "krypton_ingot","rubidium_ingot","strontium_ingot","yttrium_ingot","zirconium_ingot","niobium_ingot","molybdenum_ingot","technetium_ingot","ruthenium_ingot","rhodium_ingot","palladium_ingot","silver_ingot","cadmium_ingot","indium_ingot","tin_ingot","antimony_ingot","tellurium_ingot",
         "iodine_ingot","xenon_ingot","cesium_ingot","barium_ingot","lanthanum_ingot","cerium_ingot","praseodymium_ingot","neodymium_ingot","promethium_ingot","samarium_ingot","europium_ingot","gadolinium_ingot","tebrium_ingot","dysprosium_ingot","holmium_ingot","eribium_ingot","thulium_ingot",
         "ytterbium_ingot","lutetium_ingot","hafnium_ingot","tantalum_ingot","tungsten_ingot","rhenium_ingot","osmium_ingot","iridium_ingot","platinum_ingot","mercury_ingot","thallium_ingot","lead_ingot","bismuth_ingot","polonium_ingot","astatine","radon_ingot","francium_ingot",
         "radium_ingot","actinium_ingot","thorium_ingot","protactinium_ingot","uranium_ingot","neptunium_ingot","plutonium_ingot","americium_ingot","curium_ingot","berkelium_ingot","californium_ingot","einsteinium_ingot","fermium_ingot","mendelevium_ingot","nobelium_ingot","lawrencium_ingot",
         "rutherfordium_ingot","dubnium_ingot","seaborgium_ingot","bohrium_ingot","hassium_ingot","meiterium_ingot","darmstadtium_ingot","roentgenium_ingot","copernicium_ingot","nihonium_ingot","flerovium_ingot","moscovium_ingot","livermorium_ingot","tennessine_ingot","oganesson_ingot"]

for itemName in toAdd:
    name = itemName;
    name = name.replace("_ingot","")


    #ingot tags
    os.chdir('src/main/resources/data/forge/tags/items/ingots')

    file = open(name+'.json','w+')
    contents = """{{
      \"replace\": false,
      \"values\": [
        \"rankine:{}_ingot\"
      ]
    }}""".format(name)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    os.chdir(mainDir)


    #nugget tags
    os.chdir('src/main/resources/data/forge/tags/items/nuggets')

    file = open(name+'.json','w+')
    contents = """{{
      \"replace\": false,
      \"values\": [
        \"rankine:{}_nugget\"
      ]
    }}""".format(name)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    os.chdir(mainDir)


    #block tags
    os.chdir('src/main/resources/data/forge/tags/items/storage_blocks')

    file = open(name+'.json','w+')
    contents = """{{
      \"replace\": false,
      \"values\": [
        \"rankine:{}_block\"
      ]
    }}""".format(name)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()
    os.chdir(mainDir)
