import os


#Variants to add
basicblock = False
slabs = False
stairs = False
walls = False
fences = False
pressureplates = False
buttons = False
#trapdoors = False
doors = False
leaves = False
saplings = False
logs = False
#signs = False


#Settings
autoDetect = False #Use for stone blocks for generation of bricks, smooth, etc

#Adds a cubeall block slab, stairs, and wall variants
#this file should go in the "project-rankine" folder. Outside "src"
mainDir = str(os.getcwd())


#Get block name 'example_block'
blk = input("Enter base block name:")

#Get block type for basic properties 'wood, stone, ect.'
blkType = "stone"
#blkType = input("Enter block material (stone, wood, other) :")




langName = ""
isSmooth = 0
makesSmooth = 0
makesBrick = 0

if autoDetect == False:

    #Get texture name 'cedar_planks'
    textName = input("Enter texture name (ex. cedar_planks) :")

    #Is the block smooth (affects slab recipe)
    isSmooth = int(input("Is the block smooth (True = 1, False = 0)?: "))

    #Does this block make a smooth variant (adds smooth furnace recipe based on block name)?
    makesSmooth = int(input("Does this block make a smooth variant through furnace (True = 1, False = 0)?: "))

    #Does this block make a brick (adds brick recipe based on block name)?
    makesBrick = int(input("Does this block make a STONE brick (DO NOT USE IF THIS BLOCK IS THE BRICK) (True = 1, False = 0)?: "))

    langName = input("Localization name?: ")

else:
    textName = blk
    if "smooth" in blk:
        isSmooth = 1
        makesSmooth = 0
        makesBrick = 0
    elif "bricks" in blk:
        isSmooth = 0
        makesSmooth = 0
        makesBrick = 0
    else:
        isSmooth = 0
        makesSmooth = 1
        makesBrick = 1
    maxcount = len(blk.split("_"))
    count = 0
    for i in blk.split("_"):
        langName += i.capitalize()
        count += 1
        if count != maxcount:
            langName += " "

stoneProp = "Block.Properties.create(Material.ROCK).sound(SoundType.STONE).harvestTool(ToolType.PICKAXE).hardnessAndResistance(1.5F, 6.0F).harvestLevel(0))"
woodProp = "Block.Properties.create(Material.WOOD).sound(SoundType.WOOD).harvestTool(ToolType.AXE).hardnessAndResistance(2.0F, 3.0F).harvestLevel(0))"
defProp = "Block.Properties.create(Material.MISCELLANEOUS).sound(SoundType.STONE).hardnessAndResistance(1.0F, 1.0F).harvestLevel(0))"







###BASIC_BLOCK--------------------------------------------------------------------------

if basicblock == True:

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(blk+'.json','w+')
    contents = """{{
        \"variants\": {{
        \"\": {{ \"model\": \"rankine:block/{}\" }}
        }}
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'.json','w+')
    contents = """{{
        \"parent": \"block/cube_all\",
        \"textures\": {{
        \"all\": \"rankine:block/{}\"
        }}
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #item model
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'.json','w+')
    contents = """{{
        \"parent\": \"rankine:block/{}\"
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\":
      [
        {{ \"rolls\": 1,
          \"entries\":
          [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{}\"
            }}
          ],
          \"conditions\":
          [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)
	
    if makesBrick == 1:
        #recipes
        os.chdir('src/main/resources/data/rankine/recipes/')

##        file = open(blk+'_bricks.json','w+')
##        contents = """{{
##          \"type\": \"minecraft:crafting_shaped\",
##          \"pattern\": [
##                \"bb \",
##                \"bb \"
##          ],
##          \"key\": {{
##                \"b\": {{
##                  \"item\": \"rankine:{BLK}\"
##                }}
##          }},
##          \"result\": {{
##                \"item\": \"rankine:{BLK}_bricks\",
##                \"count\": 4
##          }}
##        }}""".format(BLK=blk)
##
##        file.write(contents)
##        print("Generated "+file.name+"!")
##        file.close()
        
        #file = open(blk+'_bricks_with_mortar.json','w+')
        file = open(blk+'_bricks.json','w+')
        contents = """{{
          \"type\": \"minecraft:crafting_shaped\",
          \"pattern\": [
                \"bmb\",
                \"mbm\",
                \"bmb\"
          ],
          \"key\": {{
                \"b\": {{
                  \"item\": \"rankine:{BLK}\"
                }},
                \"m\": {{
                  \"item\": \"rankine:mortar\"
                }}
          }},
          \"result\": {{
                \"item\": \"rankine:{BLK}_bricks\",
                \"count\": 6
          }}
        }}""".format(BLK=blk)

        file.write(contents)
        print("Generated "+file.name+"!")
        file.close()
        
        file = open(blk+'_bricks_from_'+blk+'_stonecutter.json','w+')
        contents = """{{
          \"type\": \"minecraft:stonecutting\",
          \"ingredient\": {{
                  \"item\": \"rankine:{BLK}\"
          }},
          \"result\": \"rankine:{BLK}_bricks\",
          \"count\": 1
        }}""".format(BLK=blk)

        file.write(contents)
        print("Generated "+file.name+"!")
        file.close()

        os.chdir(mainDir)
    
    if makesSmooth == 1:
        #recipes
        os.chdir('src/main/resources/data/rankine/recipes/')

        file = open('smooth_'+blk+'.json','w+')
        contents = """{{
          \"type\": \"minecraft:smelting\",
          \"ingredient\": {{
                  \"item\": \"rankine:{BLK}\"
          }},
          \"result\": \"rankine:smooth_{BLK}\",
          \"experience\": 0.1,
          \"cookingtime\": 200
        }}""".format(BLK=blk)

        file.write(contents)
        print("Generated "+file.name+"!")
        file.close()

        os.chdir(mainDir)


###SLABS--------------------------------------------------------------------------

if slabs == True:
    
    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(blk+'_slab.json','w+')
    if isSmooth == 1:
        contents = '''{{
        \"variants\": {{
            \"type=bottom\": {{ \"model\": \"rankine:block/{BLK}_slab\" }},
            \"type=top\": {{ \"model\": \"rankine:block/{BLK}_slab_top\" }},
            \"type=double\": {{ \"model\": \"rankine:block/{BLK}_slab_double\" }}
            }}
        }}'''.format(BLK=blk)
    else:
        contents = '''{{
        \"variants\": {{
            \"type=bottom\": {{ \"model\": \"rankine:block/{BLK}_slab\" }},
            \"type=top\": {{ \"model\": \"rankine:block/{BLK}_slab_top\" }},
            \"type=double\": {{ \"model\": \"rankine:block/{BLK}\" }}
            }}
        }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_slab.json','w+')
    contents = """{{
      \"parent\": \"block/slab\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}\",
        \"top\": \"rankine:block/{BLK}\",
        \"side\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)
    
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    
    if isSmooth == 1:
        file = open(blk+'_slab_double.json','w+')
        contents = """{{
          \"parent\": \"block/cube_column\",
          \"textures\": {{
                \"end\": \"rankine:block/{BLK}\",
                \"side\": \"rankine:block/{BLK}_slab_side\"
          }}
        }}""".format(BLK=textName)
    
        file.write(contents)
        print("Generated "+file.name+"!")
        file.close()


    file = open(blk+'_slab_top.json','w+')
    contents = """{{
      \"parent\": \"block/slab_top\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}\",
        \"top\": \"rankine:block/{BLK}\",
        \"side\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)
    
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_slab.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{BLK}_slab\"
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'_slab.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"functions\": [
                {{
                  \"function\": \"minecraft:set_count\",
                  \"conditions\": [
                    {{
                      \"condition\": \"minecraft:block_state_property\",
                      \"block\": \"rankine:{BLK}_slab\",
                      \"properties\": {{
                        \"type\": \"double\"
                      }}
                    }}
                  ],
                  \"count\": 2
                }},
                {{
                  \"function\": \"minecraft:explosion_decay\"
                }}
              ],
              \"name\": \"rankine:{BLK}_slab\"
            }}
          ]
        }}
      ]
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_slab.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"pattern\": [
        \"###\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_slab\",
        \"count\": 6
      }}
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_slab_from_'+blk+'_stonecutter.json','w+')
    contents = """{{
      \"type\": \"minecraft:stonecutting\",
      \"ingredient\": {{
          \"item\": \"rankine:{BLK}\"
      }},
      \"result\": \"rankine:{BLK}_slab\",
      \"count\": 2
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)






###STAIRS----------------------------------------------------------------------

if stairs == True:

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')

    file = open(blk+'_stairs.json','w+')
    contents = """{{
      \"variants\": {{
        \"facing=east,half=bottom,shape=straight\":  {{ \"model\": \"rankine:block/{BLK}_stairs\" }},
        \"facing=west,half=bottom,shape=straight\":  {{ \"model\": \"rankine:block/{BLK}_stairs\", \"y\": 180, \"uvlock\": true }},
        \"facing=south,half=bottom,shape=straight\": {{ \"model\": \"rankine:block/{BLK}_stairs\", \"y\": 90, \"uvlock\": true }},
        \"facing=north,half=bottom,shape=straight\": {{ \"model\": \"rankine:block/{BLK}_stairs\", \"y\": 270, \"uvlock\": true }},
        \"facing=east,half=bottom,shape=outer_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\" }},
        \"facing=west,half=bottom,shape=outer_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"y\": 180, \"uvlock\": true }},
        \"facing=south,half=bottom,shape=outer_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"y\": 90, \"uvlock\": true }},
        \"facing=north,half=bottom,shape=outer_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"y\": 270, \"uvlock\": true }},
        \"facing=east,half=bottom,shape=outer_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"y\": 270, \"uvlock\": true }},
        \"facing=west,half=bottom,shape=outer_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"y\": 90, \"uvlock\": true }},
        \"facing=south,half=bottom,shape=outer_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\" }},
        \"facing=north,half=bottom,shape=outer_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"y\": 180, \"uvlock\": true }},
        \"facing=east,half=bottom,shape=inner_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\" }},
        \"facing=west,half=bottom,shape=inner_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"y\": 180, \"uvlock\": true }},
        \"facing=south,half=bottom,shape=inner_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"y\": 90, \"uvlock\": true }},
        \"facing=north,half=bottom,shape=inner_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"y\": 270, \"uvlock\": true }},
        \"facing=east,half=bottom,shape=inner_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"y\": 270, \"uvlock\": true }},
        \"facing=west,half=bottom,shape=inner_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"y\": 90, \"uvlock\": true }},
        \"facing=south,half=bottom,shape=inner_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\" }},
        \"facing=north,half=bottom,shape=inner_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"y\": 180, \"uvlock\": true }},
        \"facing=east,half=top,shape=straight\":  {{ \"model\": \"rankine:block/{BLK}_stairs\", \"x\": 180, \"uvlock\": true }},
        \"facing=west,half=top,shape=straight\":  {{ \"model\": \"rankine:block/{BLK}_stairs\", \"x\": 180, \"y\": 180, \"uvlock\": true }},
        \"facing=south,half=top,shape=straight\": {{ \"model\": \"rankine:block/{BLK}_stairs\", \"x\": 180, \"y\": 90, \"uvlock\": true }},
        \"facing=north,half=top,shape=straight\": {{ \"model\": \"rankine:block/{BLK}_stairs\", \"x\": 180, \"y\": 270, \"uvlock\": true }},
        \"facing=east,half=top,shape=outer_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"y\": 90, \"uvlock\": true }},
        \"facing=west,half=top,shape=outer_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"y\": 270, \"uvlock\": true }},
        \"facing=south,half=top,shape=outer_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"y\": 180, \"uvlock\": true }},
        \"facing=north,half=top,shape=outer_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"uvlock\": true }},
        \"facing=east,half=top,shape=outer_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"uvlock\": true }},
        \"facing=west,half=top,shape=outer_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"y\": 180, \"uvlock\": true }},
        \"facing=south,half=top,shape=outer_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"y\": 90, \"uvlock\": true }},
        \"facing=north,half=top,shape=outer_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_outer\", \"x\": 180, \"y\": 270, \"uvlock\": true }},
        \"facing=east,half=top,shape=inner_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"y\": 90, \"uvlock\": true }},
        \"facing=west,half=top,shape=inner_right\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"y\": 270, \"uvlock\": true }},
        \"facing=south,half=top,shape=inner_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"y\": 180, \"uvlock\": true }},
        \"facing=north,half=top,shape=inner_right\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"uvlock\": true }},
        \"facing=east,half=top,shape=inner_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"uvlock\": true }},
        \"facing=west,half=top,shape=inner_left\":  {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"y\": 180, \"uvlock\": true }},
        \"facing=south,half=top,shape=inner_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"y\": 90, \"uvlock\": true }},
        \"facing=north,half=top,shape=inner_left\": {{ \"model\": \"rankine:block/{BLK}_stairs_inner\", \"x\": 180, \"y\": 270, \"uvlock\": true }}
      }}
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated stairs file!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_stairs.json','w+')
    contents = """{{
      \"parent\": \"block/stairs\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}\",
        \"top\": \"rankine:block/{BLK}\",
        \"side\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_stairs_inner.json','w+')
    contents = """{{
      \"parent\": \"block/inner_stairs\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}\",
        \"top\": \"rankine:block/{BLK}\",
        \"side\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_stairs_outer.json','w+')
    contents = """{{
      \"parent\": \"block/outer_stairs\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}\",
        \"top\": \"rankine:block/{BLK}\",
        \"side\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)


    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')


    file = open(blk+'_stairs.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{BLK}_stairs\"
    }}
    """.format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')


    file = open(blk+'_stairs.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\":
      [
        {{ \"rolls\": 1,
          \"entries\":
          [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{BLK}_stairs\"
            }}
          ],
          \"conditions\":
          [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_stairs.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"pattern\": [
        \"#  \",
        \"## \",
        \"###\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_stairs\",
        \"count\": 4
      }}
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_stairs_from_'+blk+'_stonecutter.json','w+')
    contents = """{{
      \"type\": \"minecraft:stonecutting\",
      \"ingredient\": {{
          \"item\": \"rankine:{BLK}\"
      }},
      \"result\": \"rankine:{BLK}_stairs\",
      \"count\": 1
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)
    



###WALLS--------------------------------------------------------------------

if walls == True:

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')

    file = open(blk+'_wall.json','w+')
    contents = '''{{
    \"multipart\": [
        {{   \"when\": {{\"up\": \"true\" }},
            \"apply\": {{ \"model\": \"rankine:block/{BLK}_wall_post\" }}
        }},
        {{   \"when\": {{ \"north\": \"true\" }},
            \"apply\": {{ \"model\": \"rankine:block/{BLK}_wall_side\", \"uvlock\": true }}
        }},
        {{   \"when\": {{ \"east\": \"true\" }},
            \"apply\": {{ \"model\": \"rankine:block/{BLK}_wall_side\", \"y\": 90, \"uvlock\": true }}
        }},
        {{   \"when\": {{ \"south\": \"true\" }},
            \"apply\": {{ \"model\": \"rankine:block/{BLK}_wall_side\", \"y\": 180, \"uvlock\": true }}
        }},
        {{   \"when\": {{ \"west\": \"true\" }},
            \"apply\": {{ \"model\": \"rankine:block/{BLK}_wall_side\", \"y\": 270, \"uvlock\": true }}
        }}
    ]
    }}'''.format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_wall_side.json','w+')
    contents = """{{
        "parent": "block/template_wall_side",
        "textures": {{
            "wall": "rankine:block/{BLK}"
        }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_wall_post.json','w+')
    contents = """{{
        "parent": "block/template_wall_post",
        "textures": {{
            "wall": "rankine:block/{BLK}"
        }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_wall_inventory.json','w+')
    contents = """{{
        "parent": "block/wall_inventory",
        "textures": {{
            "wall": "rankine:block/{BLK}"
        }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)




    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_wall.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{BLK}_wall_inventory\"
    }}
    """.format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')


    file = open(blk+'_wall.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\":
      [
        {{ \"rolls\": 1,
          \"entries\":
          [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{BLK}_wall\"
            }}
          ],
          \"conditions\":
          [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_wall.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"pattern\": [
        \"###\",
        \"###\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_wall\",
        \"count\": 6
      }}
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_wall_from_'+blk+'_stonecutter.json','w+')
    contents = """{{
      \"type\": \"minecraft:stonecutting\",
      \"ingredient\": {{
          \"item\": \"rankine:{BLK}\"
      }},
      \"result\": \"rankine:{BLK}_wall\",
      \"count\": 1
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)
    

###FENCES-----------------------------------------------------------------------------------------------------------------


if fences == True:

    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')

    file = open(blk+'_fence.json','w+')
    contents = '''{{
      \"multipart\": [
        {{   \"apply\": {{ \"model\": \"rankine:block/{BLK}_fence_post\" }}}},
        {{   \"when\": {{ \"north\": \"true\" }},
          \"apply\": {{ \"model\": \"rankine:block/{BLK}_fence_side\", \"uvlock\": true }}
        }},
        {{   \"when\": {{ \"east\": \"true\" }},
          \"apply\": {{ \"model\": \"rankine:block/{BLK}_fence_side\", \"y\": 90, \"uvlock\": true }}
        }},
        {{   \"when\": {{ \"south\": \"true\" }},
          \"apply\": {{ \"model\": \"rankine:block/{BLK}_fence_side\", \"y\": 180, \"uvlock\": true }}
        }},
        {{   \"when\": {{ \"west\": \"true\" }},
          \"apply\": {{ \"model\": \"rankine:block/{BLK}_fence_side\", \"y\": 270, \"uvlock\": true }}
        }}
      ]
    }}'''.format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()



    file = open(blk+'_fence_gate.json','w+')
    contents = '''{{
      \"variants\": {{
        \"facing=south,in_wall=false,open=false\": {{ \"model\": \"rankine:block/{BLK}_fence_gate\", \"uvlock\": true }},
        \"facing=west,in_wall=false,open=false\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate\", \"uvlock\": true, \"y\": 90 }},
        \"facing=north,in_wall=false,open=false\": {{ \"model\": \"rankine:block/{BLK}_fence_gate\", \"uvlock\": true, \"y\": 180 }},
        \"facing=east,in_wall=false,open=false\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate\", \"uvlock\": true, \"y\": 270 }},
        \"facing=south,in_wall=false,open=true\": {{ \"model\": \"rankine:block/{BLK}_fence_gate_open\", \"uvlock\": true }},
        \"facing=west,in_wall=false,open=true\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate_open\", \"uvlock\": true, \"y\": 90 }},
        \"facing=north,in_wall=false,open=true\": {{ \"model\": \"rankine:block/{BLK}_fence_gate_open\", \"uvlock\": true, \"y\": 180 }},
        \"facing=east,in_wall=false,open=true\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate_open\", \"uvlock\": true, \"y\": 270 }},
        \"facing=south,in_wall=true,open=false\": {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall\", \"uvlock\": true }},
        \"facing=west,in_wall=true,open=false\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall\", \"uvlock\": true, \"y\": 90 }},
        \"facing=north,in_wall=true,open=false\": {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall\", \"uvlock\": true, \"y\": 180 }},
        \"facing=east,in_wall=true,open=false\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall\", \"uvlock\": true, \"y\": 270 }},
        \"facing=south,in_wall=true,open=true\": {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall_open\", \"uvlock\": true }},
        \"facing=west,in_wall=true,open=true\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall_open\", \"uvlock\": true, \"y\": 90 }},
        \"facing=north,in_wall=true,open=true\": {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall_open\", \"uvlock\": true, \"y\": 180 }},
        \"facing=east,in_wall=true,open=true\":  {{ \"model\": \"rankine:block/{BLK}_fence_gate_wall_open\", \"uvlock\": true, \"y\": 270 }}
      }}
    }}'''.format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()



    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_fence_inventory.json','w+')
    contents = """{{
      \"parent\": \"block/fence_inventory\",
      \"textures\": {{
        \"texture\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_post.json','w+')
    contents = """{{
      \"parent\": \"block/fence_post\",
      \"textures\": {{
        \"texture\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_side.json','w+')
    contents = """{{
      \"parent\": \"block/fence_side\",
      \"textures\": {{
        \"texture\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_gate.json','w+')
    contents = """{{
      \"parent\": \"block/template_fence_gate\",
      \"textures\": {{
        \"texture\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_gate_open.json','w+')
    contents = """{{
      \"parent\": \"block/template_fence_gate_open\",
      \"textures\": {{
        \"texture\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_gate_wall.json','w+')
    contents = """{{
      \"parent\": \"block/template_fence_gate_wall\",
      \"textures\": {{
        \"texture\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_gate_wall_open.json','w+')
    contents = """{{
      \"parent\": \"block/template_fence_gate_wall_open\",
      \"textures\": {{
        \"texture\": \"rankine:block/{BLK}\"
      }}
    }}""".format(BLK=textName)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    
    os.chdir(mainDir)




    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_fence.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{BLK}_fence_inventory\"
    }}
    """.format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_gate.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{BLK}_fence_gate\"
    }}
    """.format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    
    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')


    file = open(blk+'_fence.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\":
      [
        {{ \"rolls\": 1,
          \"entries\":
          [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{BLK}_fence_inventory\"
            }}
          ],
          \"conditions\":
          [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_gate.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\":
      [
        {{ \"rolls\": 1,
          \"entries\":
          [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{BLK}_fence_gate\"
            }}
          ],
          \"conditions\":
          [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    
    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_fence.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"pattern\": [
        \"#S#\",
        \"#S#\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}\"
        }},
        \"S\": {{
          \"item\": \"minecraft:stick\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_fence\",
        \"count\": 3
      }}
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_fence_gate.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"pattern\": [
        \"S#S\",
        \"S#S\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}\"
        }},
        \"S\": {{
          \"item\": \"minecraft:stick\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_fence_gate\",
        \"count\": 1
      }}
    }}""".format(BLK=blk)

    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    os.chdir(mainDir)
    

###PRESSURE_PLATES--------------------------------------------------------------------------

if pressureplates == True:
    
    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(blk+'_pressure_plate.json','w+')
    contents = """{{
      \"variants\": {{
        \"powered=false\": {{ \"model\": \"rankine:block/{BLK}_pressure_plate\" }},
        \"powered=true\": {{ \"model\": \"rankine:block/{BLK}_pressure_plate_down\" }}
      }}
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_pressure_plate.json','w+')
    contents = """{{
      \"parent\": \"block/pressure_plate_up\",
      \"textures\": {{
        \"texture\": \"rankine:block/{}\"
      }}
    }}""".format(textName)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()


    file = open(blk+'_pressure_plate_down.json','w+')
    contents = """{{
      \"parent\": \"block/pressure_plate_down\",
      \"textures\": {{
        \"texture\": \"rankine:block/{}\"
      }}
    }}""".format(textName)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_pressure_plate.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{}_pressure_plate\"
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'_pressure_plate.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{}_pressure_plate\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_pressure_plate.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"pattern\": [
        \"##\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{}\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{}_pressure_plate\",
        \"count\": 1
      }}
    }}""".format(textName, blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
###BUTTONS--------------------------------------------------------------------------

if buttons == True:
    
    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(blk+'_button.json','w+')
    contents = '''{{
      \"variants\": {{
        \"face=floor,facing=east,powered=false\":  {{ \"model\": \"rankine:block/{BLK}_button\", \"y\": 90 }},
        \"face=floor,facing=west,powered=false\":  {{ \"model\": \"rankine:block/{BLK}_button\", \"y\": 270 }},
        \"face=floor,facing=south,powered=false\": {{ \"model\": \"rankine:block/{BLK}_button\", \"y\": 180 }},
        \"face=floor,facing=north,powered=false\": {{ \"model\": \"rankine:block/{BLK}_button\" }},
        \"face=wall,facing=east,powered=false\":  {{ \"model\": \"rankine:block/{BLK}_button\", \"uvlock\": true, \"x\": 90, \"y\": 90 }},
        \"face=wall,facing=west,powered=false\":  {{ \"model\": \"rankine:block/{BLK}_button\", \"uvlock\": true, \"x\": 90, \"y\": 270 }},
        \"face=wall,facing=south,powered=false\": {{ \"model\": \"rankine:block/{BLK}_button\", \"uvlock\": true, \"x\": 90, \"y\": 180 }},
        \"face=wall,facing=north,powered=false\": {{ \"model\": \"rankine:block/{BLK}_button\", \"uvlock\": true, \"x\": 90 }},
        \"face=ceiling,facing=east,powered=false\":  {{ \"model\": \"rankine:block/{BLK}_button\", \"x\": 180, \"y\": 270 }},
        \"face=ceiling,facing=west,powered=false\":  {{ \"model\": \"rankine:block/{BLK}_button\", \"x\": 180, \"y\": 90 }},
        \"face=ceiling,facing=south,powered=false\": {{ \"model\": \"rankine:block/{BLK}_button\", \"x\": 180 }},
        \"face=ceiling,facing=north,powered=false\": {{ \"model\": \"rankine:block/{BLK}_button\", \"x\": 180, \"y\": 180 }},
        \"face=floor,facing=east,powered=true\":  {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"y\": 90 }},
        \"face=floor,facing=west,powered=true\":  {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"y\": 270 }},
        \"face=floor,facing=south,powered=true\": {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"y\": 180 }},
        \"face=floor,facing=north,powered=true\": {{ \"model\": \"rankine:block/{BLK}_button_pressed\" }},
        \"face=wall,facing=east,powered=true\":  {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"uvlock\": true, \"x\": 90, \"y\": 90 }},
        \"face=wall,facing=west,powered=true\":  {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"uvlock\": true, \"x\": 90, \"y\": 270 }},
        \"face=wall,facing=south,powered=true\": {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"uvlock\": true, \"x\": 90, \"y\": 180 }},
        \"face=wall,facing=north,powered=true\": {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"uvlock\": true, \"x\": 90 }},
        \"face=ceiling,facing=east,powered=true\":  {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"x\": 180, \"y\": 270 }},
        \"face=ceiling,facing=west,powered=true\":  {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"x\": 180, \"y\": 90 }},
        \"face=ceiling,facing=south,powered=true\": {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"x\": 180 }},
        \"face=ceiling,facing=north,powered=true\": {{ \"model\": \"rankine:block/{BLK}_button_pressed\", \"x\": 180, \"y\": 180 }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_button_pressed.json','w+')
    contents = """{{
      \"parent\": \"block/button_pressed\",
      \"textures\": {{
        \"texture\": \"rankine:block/{}\"
      }}
    }}""".format(textName)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_button.json','w+')
    contents = """{{
      \"parent\": \"block/button\",
      \"textures\": {{
        \"texture\": \"rankine:block/{}\"
      }}
    }}""".format(textName)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_button_inventory.json','w+')
    contents = """{{
      \"parent\": \"block/button_inventory\",
      \"textures\": {{
        \"texture\": \"rankine:block/{}\"
      }}
    }}""".format(textName)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_button.json','w+')
    contents = """{{
      \"parent\": \"rankine:block/{}_button_inventory\"
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'_button.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{}_button\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_pressure_plate.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shapeless\",
      \"group\": \"wooden_button\",
      \"ingredients\": [
        {{
          \"item\": \"rankine:{}\"
        }}
      ],
      \"result\": {{
        \"item\": \"rankine:{}_button\"
      }}
    }}""".format(textName, blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

###LOGS--------------------------------------------------------------------------

if logs == True:
    
    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(blk+'_log.json','w+')
    contents = '''{{
      \"variants\": {{
        \"axis=y\":  {{ \"model\": \"rankine:block/{BLK}_log\" }},
        \"axis=z\":   {{ \"model\": \"rankine:block/{BLK}_log\", \"x\": 90 }},
        \"axis=x\":   {{ \"model\": \"rankine:block/{BLK}_log\", \"x\": 90, \"y\": 90 }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_wood.json','w+')
    contents = '''{{
      \"variants\": {{
        \"axis=y\": {{ \"model\": \"rankine:block/{BLK}_wood\" }},
        \"axis=z\": {{ \"model\": \"rankine:block/{BLK}_wood\", \"x\": 90 }},
        \"axis=x\": {{ \"model\": \"rankine:block/{BLK}_wood\", \"x\": 90, \"y\": 90 }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_log.json','w+')
    contents = '''{{
      \"variants\": {{
        \"axis=y\":  {{ \"model\": \"rankine:block/stripped_{BLK}_log\" }},
        \"axis=z\":   {{ \"model\": \"rankine:block/stripped_{BLK}_log\", \"x\": 90 }},
        \"axis=x\":   {{ \"model\": \"rankine:block/stripped_{BLK}_log\", \"x\": 90, \"y\": 90 }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_wood.json','w+')
    contents = '''{{
      \"variants\": {{
        \"axis=y\": {{ \"model\": \"rankine:block/stripped_{BLK}_wood\" }},
        \"axis=z\": {{ \"model\": \"rankine:block/stripped_{BLK}_wood\", \"x\": 90 }},
        \"axis=x\": {{ \"model\": \"rankine:block/stripped_{BLK}_wood\", \"x\": 90, \"y\": 90 }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_log.json','w+')
    contents = '''{{
      \"parent\": \"block/cube\",
      \"textures\": {{
        \"particle\": \"rankine:block/{BLK}_log\",
        \"down\": \"rankine:block/{BLK}_log_top\",
        \"up\": \"rankine:block/{BLK}_log_top\",
        \"east\": \"rankine:block/{BLK}_log\",
        \"west\": \"rankine:block/{BLK}_log\",
        \"north\": \"rankine:block/{BLK}_log\",
        \"south\": \"rankine:block/{BLK}_log\"
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_wood.json','w+')
    contents = '''{{
      \"parent\": \"block/cube_column\",
      \"textures\": {{
        \"end\": \"rankine:block/{BLK}_log\",
        \"side\": \"rankine:block/{BLK}_log\"
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_log.json','w+')
    contents = '''{{
      \"parent\": \"block/cube\",
      \"textures\": {{
        \"particle\": \"rankine:block/stripped_{BLK}_log\",
        \"down\": \"rankine:block/stripped_{BLK}_log_top\",
        \"up\": \"rankine:block/stripped_{BLK}_log_top\",
        \"east\": \"rankine:block/stripped_{BLK}_log\",
        \"west\": \"rankine:block/stripped_{BLK}_log\",
        \"north\": \"rankine:block/stripped_{BLK}_log\",
        \"south\": \"rankine:block/stripped_{BLK}_log\"
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_wood.json','w+')
    contents = '''{{
      \"parent\": \"block/cube_column\",
      \"textures\": {{
        \"end\": \"rankine:block/stripped_{BLK}_log\",
        \"side\": \"rankine:block/stripped_{BLK}_log\"
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_log.json','w+')
    contents = '''{{
      \"parent\": \"rankine:block/{BLK}_log\"
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_wood.json','w+')
    contents = '''{{
      \"parent\": \"rankine:block/{BLK}_wood\"
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_log.json','w+')
    contents = '''{{
      \"parent\": \"rankine:block/stripped_{BLK}_log\"
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_wood.json','w+')
    contents = '''{{
      \"parent\": \"rankine:block/stripped_{BLK}_wood\"
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'_log.json','w+')
    contents = '''{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{BLK}_log\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_wood.json','w+')
    contents = '''{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:{BLK}_wood\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_log.json','w+')
    contents = '''{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:stripped_{BLK}_log\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('stripped_'+blk+'_wood.json','w+')
    contents = '''{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"name\": \"rankine:stripped_{BLK}_wood\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_wood.json','w+')
    contents = '''{{
      \"type\": \"minecraft:crafting_shaped\",
      \"group\": \"bark\",
      \"pattern\": [
        \"##\",
        \"##\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}_log\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_wood\",
        \"count\": 3
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


###SAPLINGS--------------------------------------------------------------------------

if saplings == True:
    
    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')

    file = open(blk+'_sapling.json','w+')
    contents = '''{{
      \"variants\": {{
        \"\": {{ \"model\": \"rankine:block/{BLK}_sapling\" }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('potted_'+blk+'_sapling.json','w+')
    contents = '''{{
      \"variants\": {{
        \"\": {{ \"model\": \"rankine:block/potted_{BLK}_sapling\" }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_sapling.json','w+')
    contents = '''{{
      \"parent\": \"block/cross\",
      \"textures\": {{
        \"cross\": \"rankine:block/{BLK}_sapling\"
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open('potted_'+blk+'_sapling.json','w+')
    contents = '''{{
      \"parent\": \"block/flower_pot_cross\",
      \"textures\": {{
        \"plant\": \"rankine:block/{BLK}_sapling\"
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_sapling.json','w+')
    contents = '''{{
      \"parent\": \"item/generated\",
      \"textures\": {{
        \"layer0\": \"rankine:block/{BLK}_sapling\"
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'_sapling.json','w+')
    contents = '''{{
    \"type\": \"minecraft:block\", \"pools\": [ {{ \"rolls\": 1, \"entries\": [ {{ \"type\": \"minecraft:item\", \"name\": \"rankine:{BLK}_sapling\" }} ], \"conditions\": [ {{ \"condition\": \"minecraft:survives_explosion\" }} ] }} ]
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)



###LEAVES--------------------------------------------------------------------------

if leaves == True:
    
    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')

    file = open(blk+'_leaves.json','w+')
    contents = '''{{
      \"variants\": {{
        \"\": {{\"model\": \"rankine:block/{BLK}_leaves\"}}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_leaves.json','w+')
    contents = '''{{
        \"parent\": \"block/leaves\",
        \"textures\": {{
            \"all\": \"rankine:block/{BLK}_leaves\"
        }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_leaves.json','w+')
    contents = '''{{
      \"parent\": \"rankine:block/{BLK}_leaves\"
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'_leaves.json','w+')
    contents = '''{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:alternatives\",
              \"children\": [
                {{
                  \"type\": \"minecraft:item\",
                  \"conditions\": [
                    {{
                      \"condition\": \"minecraft:alternative\",
                      \"terms\": [
                        {{
                          \"condition\": \"minecraft:match_tool\",
                          \"predicate\": {{
                            \"item\": \"minecraft:shears\"
                          }}
                        }},
                        {{
                          \"condition\": \"minecraft:match_tool\",
                          \"predicate\": {{
                            \"enchantments\": [
                              {{
                                \"enchantment\": \"minecraft:silk_touch\",
                                \"levels\": {{
                                  \"min\": 1
                                }}
                              }}
                            ]
                          }}
                        }}
                      ]
                    }}
                  ],
                  \"name\": \"rankine:{BLK}_leaves\"
                }},
                {{
                  \"type\": \"minecraft:item\",
                  \"conditions\": [
                    {{
                      \"condition\": \"minecraft:survives_explosion\"
                    }},
                    {{
                      \"condition\": \"minecraft:table_bonus\",
                      \"enchantment\": \"minecraft:fortune\",
                      \"chances\": [
                        0.05,
                        0.0625,
                        0.083333336,
                        0.1
                      ]
                    }}
                  ],
                  \"name\": \"rankine:{BLK}_sapling\"
                }}
              ]
            }}
          ]
        }},
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"conditions\": [
                {{
                  \"condition\": \"minecraft:table_bonus\",
                  \"enchantment\": \"minecraft:fortune\",
                  \"chances\": [
                    0.02,
                    0.022222223,
                    0.025,
                    0.033333335,
                    0.1
                  ]
                }}
              ],
              \"functions\": [
                {{
                  \"function\": \"minecraft:set_count\",
                  \"count\": {{
                    \"min\": 1.0,
                    \"max\": 2.0,
                    \"type\": \"minecraft:uniform\"
                  }}
                }},
                {{
                  \"function\": \"minecraft:explosion_decay\"
                }}
              ],
              \"name\": \"minecraft:stick\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:inverted\",
              \"term\": {{
                \"condition\": \"minecraft:alternative\",
                \"terms\": [
                  {{
                    \"condition\": \"minecraft:match_tool\",
                    \"predicate\": {{
                      \"item\": \"minecraft:shears\"
                    }}
                  }},
                  {{
                    \"condition\": \"minecraft:match_tool\",
                    \"predicate\": {{
                      \"enchantments\": [
                        {{
                          \"enchantment\": \"minecraft:silk_touch\",
                          \"levels\": {{
                            \"min\": 1
                          }}
                        }}
                      ]
                    }}
                  }}
                ]
              }}
            }}
          ]
        }}
      ]
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)



###DOORS--------------------------------------------------------------------------

if doors == True:
    
    #blockstates
    os.chdir('src/main/resources/assets/rankine/blockstates/')
    
    file = open(blk+'_door.json','w+')
    contents = '''{{
      \"variants\": {{
        \"facing=east,half=lower,hinge=left,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom\" }},
        \"facing=south,half=lower,hinge=left,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_bottom\", \"y\": 90 }},
        \"facing=west,half=lower,hinge=left,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom\", \"y\": 180 }},
        \"facing=north,half=lower,hinge=left,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_bottom\", \"y\": 270 }},
        \"facing=east,half=lower,hinge=right,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\" }},
        \"facing=south,half=lower,hinge=right,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\", \"y\": 90 }},
        \"facing=west,half=lower,hinge=right,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\", \"y\": 180 }},
        \"facing=north,half=lower,hinge=right,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\", \"y\": 270 }},
        \"facing=east,half=lower,hinge=left,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\", \"y\": 90 }},
        \"facing=south,half=lower,hinge=left,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\", \"y\": 180 }},
        \"facing=west,half=lower,hinge=left,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\", \"y\": 270 }},
        \"facing=north,half=lower,hinge=left,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_bottom_hinge\" }},
        \"facing=east,half=lower,hinge=right,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom\", \"y\": 270 }},
        \"facing=south,half=lower,hinge=right,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_bottom\" }},
        \"facing=west,half=lower,hinge=right,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_bottom\", \"y\": 90 }},
        \"facing=north,half=lower,hinge=right,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_bottom\", \"y\": 180 }},
        \"facing=east,half=upper,hinge=left,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_top\" }},
        \"facing=south,half=upper,hinge=left,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_top\", \"y\": 90 }},
        \"facing=west,half=upper,hinge=left,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_top\", \"y\": 180 }},
        \"facing=north,half=upper,hinge=left,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_top\", \"y\": 270 }},
        \"facing=east,half=upper,hinge=right,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\" }},
        \"facing=south,half=upper,hinge=right,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\", \"y\": 90 }},
        \"facing=west,half=upper,hinge=right,open=false\":  {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\", \"y\": 180 }},
        \"facing=north,half=upper,hinge=right,open=false\": {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\", \"y\": 270 }},
        \"facing=east,half=upper,hinge=left,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\", \"y\": 90 }},
        \"facing=south,half=upper,hinge=left,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\", \"y\": 180 }},
        \"facing=west,half=upper,hinge=left,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\", \"y\": 270 }},
        \"facing=north,half=upper,hinge=left,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_top_hinge\" }},
        \"facing=east,half=upper,hinge=right,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_top\", \"y\": 270 }},
        \"facing=south,half=upper,hinge=right,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_top\" }},
        \"facing=west,half=upper,hinge=right,open=true\":  {{ \"model\": \"rankine:block/{BLK}_door_top\", \"y\": 90 }},
        \"facing=north,half=upper,hinge=right,open=true\": {{ \"model\": \"rankine:block/{BLK}_door_top\", \"y\": 180 }}
      }}
    }}'''.format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #block model
    os.chdir('src/main/resources/assets/rankine/models/block/')

    file = open(blk+'_door_top_hinge.json','w+')
    contents = """{{
      \"parent\": \"block/door_top_rh\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}_door_bottom\",
        \"top\": \"rankine:block/{BLK}_door_top\"
      }}
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_door_top.json','w+')
    contents = """{{
      \"parent\": \"block/door_top\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}_door_bottom\",
        \"top\": \"rankine:block/{BLK}_door_top\"
      }}
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_door_bottom_hinge.json','w+')
    contents = """{{
      \"parent\": \"block/door_bottom_rh\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}_door_bottom\",
        \"top\": \"rankine:block/{BLK}_door_top\"
      }}
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    file = open(blk+'_door_bottom.json','w+')
    contents = """{{
      \"parent\": \"block/door_bottom\",
      \"textures\": {{
        \"bottom\": \"rankine:block/{BLK}_door_bottom\",
        \"top\": \"rankine:block/{BLK}_door_top\"
      }}
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)

    
    #item models
    os.chdir('src/main/resources/assets/rankine/models/item/')

    file = open(blk+'_door.json','w+')
    contents = """{{
      \"parent\": \"item/generated\",
      \"textures\": {{
        \"layer0\": \"rankine:item/{BLK}_door\"
      }}
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #loottable
    os.chdir('src/main/resources/data/rankine/loot_tables/blocks/')

    file = open(blk+'_door.json','w+')
    contents = """{{
      \"type\": \"minecraft:block\",
      \"pools\": [
        {{
          \"rolls\": 1,
          \"entries\": [
            {{
              \"type\": \"minecraft:item\",
              \"conditions\": [
                {{
                  \"condition\": \"minecraft:block_state_property\",
                  \"block\": \"rankine:{BLK}_door\",
                  \"properties\": {{
                    \"half\": \"lower\"
                  }}
                }}
              ],
              \"name\": \"rankine:{BLK}_door\"
            }}
          ],
          \"conditions\": [
            {{
              \"condition\": \"minecraft:survives_explosion\"
            }}
          ]
        }}
      ]
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)


    #recipes
    os.chdir('src/main/resources/data/rankine/recipes/')

    file = open(blk+'_pressure_plate.json','w+')
    contents = """{{
      \"type\": \"minecraft:crafting_shaped\",
      \"group\": \"wooden_door\",
      \"pattern\": [
        \"##\",
        \"##\",
        \"##\"
      ],
      \"key\": {{
        \"#\": {{
          \"item\": \"rankine:{BLK}_planks\"
        }}
      }},
      \"result\": {{
        \"item\": \"rankine:{BLK}_door\",
        \"count\": 3
      }}
    }}""".format(BLK=blk)
    file.write(contents)
    print("Generated "+file.name+"!")
    file.close()

    os.chdir(mainDir)










if basicblock == True:
    #registry
    if blkType == "stone":
        print("public static final Block {} = add(\"{}\", new Block({}, MAIN);".format(blk.upper(), blk, stoneProp))
    elif blkType == "wood":
        print("public static final Block {} = add(\"{}\", new Block({}, MAIN);".format(blk.upper(), blk, woodProp))
    else:
        print("public static final Block {} = add(\"{}\", new Block({}, MAIN);".format(blk.upper(), blk, defProp))
    

if slabs == True:
    #registry
    if blkType == "stone":
        print("public static final Block {}_SLAB = add(\"{}_slab\", new RankineSlab({}, MAIN);".format(blk.upper(), blk, stoneProp))
    elif blkType == "wood":
        print("public static final Block {}_SLAB = add(\"{}_slab\", new RankineSlab({}, MAIN);".format(blk.upper(), blk, woodProp))
    else:
        print("public static final Block {}_SLAB = add(\"{}_slab\", new RankineSlab({}, MAIN);".format(blk.upper(), blk, defProp))
    

if stairs == True:
    #registry
    if blkType == "stone":
        print("public static final Block {}_STAIRS = add(\"{}_stairs\", new RankineStairs(Block.getStateById(0),{}, MAIN);".format(blk.upper(), blk, stoneProp))
    elif blkType == "wood":
        print("public static final Block {}_STAIRS = add(\"{}_stairs\", new RankineStairs(Block.getStateById(0),{}, MAIN);".format(blk.upper(), blk, woodProp))
    else:
        print("public static final Block {}_STAIRS = add(\"{}_stairs\", new RankineStairs(Block.getStateById(0),{}, MAIN);".format(blk.upper(), blk, defProp))
    

if fences == True:
    #registry
    print("public static final Block {}_FENCE = add(\"{}_fence\", new RankineWoodenFence(), MAIN);".format(blk.upper(), blk))
    print("public static final Block {}_FENCE_GATE = add(\"{}_fence_gate\", new RankineWoodenFenceGate(), MAIN);".format(blk.upper(), blk))
    

if walls == True:
    #registry
    if blkType == "stone":
        print("public static final Block {}_WALL = add(\"{}_wall\", new RankineWall({}, MAIN);".format(blk.upper(), blk, stoneProp))
    elif blkType == "wood":
        print("public static final Block {}_WALL = add(\"{}_wall\", new RankineWall({}, MAIN);".format(blk.upper(), blk, woodProp))
    else:
        print("public static final Block {}_WALL = add(\"{}_wall\", new RankineWall({}, MAIN);".format(blk.upper(), blk, defProp))


if pressureplates == True:
    #registry
    if blkType == "wood":
        print("public static final Block {}_PRESSURE_PLATE = add(\"{}_pressure_plate\", new RankineWoodenPressurePlate(), MAIN);".format(blk.upper(), blk))
    else:
        print("public static final Block {}_PRESSURE_PLATE = add(\"{}_pressure_plate\", new RankineStonePressurePlate(), MAIN);".format(blk.upper(), blk))


if buttons == True:
    #registry
    if blkType == "wood":
        print("public static final Block {}_BUTTON = add(\"{}_button\", new RankineWoodenButton(), MAIN);".format(blk.upper(), blk))
    else:
        print("public static final Block {}_BUTTON = add(\"{}_button\", new RankineStoneButton(), MAIN);".format(blk.upper(), blk))

if doors == True:
    #registry
    print("public static final Block {}_door = add(\"{}_door\", new RankineWoodenDoor(), BLOCKS, 600);".format(blk.upper(), blk))

if logs == True:
    #registry
    print("public static final Block {}_LOG = add(\"{}_log\", new LogBlock(MaterialColor.XXX, DEF_WOOD), BLOCKS, 300);".format(blk.upper(), blk))
    print("public static final Block {}_WOOD = add(\"{}_wood\", new RotatedPillarBlock(DEF_WOOD), BLOCKS, 300);".format(blk.upper(), blk))
    print("public static final Block STRIPPED_{}_LOG = add(\"stripped_{}_log\", new RotatedPillarBlock(DEF_WOOD), BLOCKS, 300);".format(blk.upper(), blk))
    print("public static final Block STRIPPED_{}_WOOD = add(\"stripped_{}_wood\", new RotatedPillarBlock(DEF_WOOD), BLOCKS, 300);".format(blk.upper(), blk))
if leaves == True:
    #registry
    print("public static final Block {}_LEAVES = add(\"{}_leaves\", new LeavesBlock(DEF_LEAVES), BLOCKS);".format(blk.upper(), blk))

if saplings == True:
    #registry
    print("public static final Block {}_SAPLING = add(\"{}_sapling\", new RankineSapling(new xxx(), sapling, 3), BLOCKS);".format(blk.upper(), blk))
    print("public static final FlowerPotBlock POTTED_{}_SAPLING = add(\"potted_{}_sapling\", new FlowerPotBlock(null, () -> {}_SAPLING, Block.Properties.create(Material.MISCELLANEOUS).hardnessAndResistance(0.0f).notSolid()));".format(blk.upper(), blk, blk.upper()))


    

if basicblock == True:
    #lang
    print("\"block.rankine.{}\": \"{}\",".format(blk, langName))
if slabs == True:
    #lang
    print("\"block.rankine.{}_slab\": \"{}\",".format(blk, langName+ " Slab"))
if stairs == True:
    #lang
    print("\"block.rankine.{}_stairs\": \"{}\",".format(blk, langName + " Stairs"))
if fences == True:
    #lang
    print("\"block.rankine.{}_fence\": \"{}\",".format(blk, langName + " Fence"))
    print("\"block.rankine.{}_fence_gate\": \"{}\",".format(blk, langName + " Fence Gate"))
if walls == True:
    #lang
    print("\"block.rankine.{}_wall\": \"{}\",".format(blk, langName + " Wall"))
if pressureplates == True:
    #lang
    print("\"block.rankine.{}_pressure_plate\": \"{}\",".format(blk, langName + " Pressure Plate"))
if buttons == True:
    #lang
    print("\"block.rankine.{}_button\": \"{}\",".format(blk, langName + " Button"))
if doors == True:
    #lang
    print("\"block.rankine.{}_DOOR\": \"{}\",".format(blk, langName + " Door"))
if logs == True:
    #lang
    print("\"block.rankine.{}_log\": \"{}\",".format(blk, langName + " Log"))
    print("\"block.rankine.{}_wood\": \"{}\",".format(blk, langName + " Wood"))
    print("\"block.rankine.stripped_{}_log\": \"{}\",".format(blk, 'Stripped ' + langName + " Log"))
    print("\"block.rankine.stripped_{}_wood\": \"{}\",".format(blk, 'Stripped ' + langName + " Log"))
if leaves == True:
    #lang
    print("\"block.rankine.{}_leaves\": \"{}\",".format(blk, langName + " Leaves"))
if saplings == True:
    #lang
    print("\"block.rankine.{}_sapling\": \"{}\",".format(blk, langName + " Sapling"))
    print("\"block.rankine.potted_{}_sapling\": \"{}\",".format(blk, 'Potted ' + langName + " Sapling"))


